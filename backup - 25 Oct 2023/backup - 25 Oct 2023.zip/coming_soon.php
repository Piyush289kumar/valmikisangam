<?php include('header.php'); ?>
<div class="container">
  <!-- Home Page Section Start -->
  <section>
    <div class="row">
      <div class="col-md-2 mt-4">
        <a style="background:#E1412E; border-radius: 12px; padding:6px 16px; color:white;" href="index.php"><i
            class="fa-solid fa-arrow-left"></i> Back</a>
      </div>
    </div>
    <div class="row mt-5 mb-5">
      <div class="col-12 text-center mt-5 mb-5">
        <h1 class="mt-5 mb-5" style="color:#f27e00; ">Coming Soon...</h1>
      </div>
    </div>
  </section>
  <!-- Home Page Section End -->
</div>
<?php include('footer.php');