<?php
$website_display_default_name = "Valmiki Sangam";
$hostname = "https://www.valmikisangam.com";
$conn = mysqli_connect('localhost', 'u423777452_valmikisangam', '00?#=>rF', 'u423777452_valmikisangam') or die("Connection Failed!!" . mysqli_connect_error());
?>