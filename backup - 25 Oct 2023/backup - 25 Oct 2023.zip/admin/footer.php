<!-- Footer -->
<div id="footer">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                               <a href="https://piyushkumar.infinityfreeapp.com">(©) Piyush kumar Raikwar द्वारा डिजाइन और विकसित</a>
            </div>
        </div>
    </div>
</div>
<!-- /Footer -->
</body>

</html>