<?php include('header.php'); ?>
<div class="container">
  <!-- Home Page Section Start -->
  <section>
    <div class="mb-4">
      <!-- uperheading Start -->
      <div class="row mt-3">
        <!-- uperheading -->
        <div class="col-12">
          <h1 class="middletext"><img src="images/logo_text.png" alt="Error"></h1>
        </div>
        <div class="col-12 sidetext mt-3">
          <p>!! जय श्रीराम !!</p>
          <p>!! जय वाल्मीकि !!</p>
        </div>
      </div>
      <!-- uperheading End -->
      <!-- middle_section Start -->
      <div class="row middle_section mb-4">
        <div class="col-12 animated animatedFadeInUp fadeInUp">
          <img src="images/main.png" alt="Logo" class="mainsectionlogo" />
        </div>
      </div>
      <!-- Middle section End -->
    </div>
  </section>
  <!-- Home Page Section End -->
</div>
<?php include('footer.php'); ?>